# Common Shared Drive Access Issues

This page provides solutions for the most frequently encountered shared drive problems. For more specific issues, refer to the dedicated troubleshooting pages.

## Cannot Access Shared Drive

### Symptoms
- "Network path not found" error
- Drive appears with a red X
- "Access denied" message

### Possible Solutions

1. **Verify your network connection**
   - Make sure your computer is connected to the company network
   - If working remotely, check that your VPN connection is active

2. **Check your credentials**
   - Your network password may have expired
   - Try logging out and back into your computer
   - Verify that you're using the correct username and password

3. **Refresh network connections**
   - Windows: Open Command Prompt and run `net use * /delete` then reconnect to drives
   - Mac: Disconnect and reconnect to the server through Finder

4. **Check for network outages**
   - Visit the [IT Status Page](http://status.example.com) to see if there are any known issues

## Slow Performance

### Symptoms
- Files take a long time to open
- Saving documents is extremely slow
- Browsing folders takes a long time

### Possible Solutions

1. **Check your connection speed**
   - Run a speed test to verify your network connection is stable
   - If on Wi-Fi, try using a wired connection

2. **Close unused applications**
   - Too many applications can consume bandwidth
   - Especially check for file syncing applications or large downloads

3. **Avoid peak usage times**
   - If possible, perform large file transfers during off-peak hours

4. **Clear cache and temporary files**
   - Windows: Delete temporary files using Disk Cleanup
   - Mac: Clear cache files from ~/Library/Caches/

## "File In Use" Errors

### Symptoms
- "This file is already open by another user" message
- Cannot edit or delete a file
- File appears to be locked

### Possible Solutions

1. **Check who has the file open**
   - Windows: Right-click on the file, select "Properties," then the "Open Files" tab
   - Contact the user who has the file open

2. **Wait and retry**
   - The file may be temporarily locked by a background process
   - Wait a few minutes and try again

3. **Try opening in read-only mode**
   - If you only need to view the file, open it as read-only
   - Make a local copy and work on it until the original is available

4. **Restart the file server**
   - Contact IT if the problem persists, as the file server may need to be restarted

## Cannot See Newly Shared Folders

### Symptoms
- Recently added folders don't appear
- You've been told you have access, but can't see the folder

### Possible Solutions

1. **Refresh your view**
   - Press F5 or right-click and select "Refresh" in the file explorer
   
2. **Reconnect to the shared drive**
   - Disconnect and reconnect to the shared drive

3. **Check your permissions**
   - Contact the folder owner to verify your permissions were set correctly

4. **Clear your credentials cache**
   - Windows: Open Credential Manager and remove saved credentials
   - Mac: Open Keychain Access and delete relevant saved passwords

## Synchronization Issues

### Symptoms
- Local copies of files don't match server versions
- Changes made by others aren't visible
- Your changes don't appear for others

### Possible Solutions

1. **Force a sync operation**
   - If using a sync client, manually initiate a sync operation

2. **Check for sync conflicts**
   - Look for files with "(Conflicted)" in their names

3. **Check sync status**
   - Verify that the sync client is running properly
   - Check for any paused sync operations

4. **Restart the sync client**
   - Close and reopen the application responsible for synchronization

## Getting Additional Help

If none of these solutions resolve your issue, please refer to the specific troubleshooting guides for:

- [Permission Problems](/troubleshooting/permission-problems)
- [Connection Errors](/troubleshooting/connection-errors)
- [Syncing Issues](/troubleshooting/syncing-issues)

If you still need assistance, follow the guidelines on the [How to Report an Issue](/guide/report-issue) page to contact IT support.