# Permission Problems

This guide addresses common permission-related issues when accessing shared drives and provides solutions to resolve them.

## Understanding Permission Errors

Permission errors occur when your user account doesn't have the necessary rights to perform an action on a shared drive or file. These errors typically appear as:

- "Access Denied"
- "You don't have permission to access this folder"
- "Contact the administrator to obtain permission"
- "You require permission from [user/group] to make changes to this file"

## Common Permission Problems and Solutions

### Cannot Access a Folder

#### Symptoms
- Receive "Access Denied" error when trying to open a folder
- Folder appears in the list but cannot be opened

#### Solutions

1. **Verify you have been granted access**
   - Contact the folder owner or your manager to confirm you should have access
   - Ask them to verify that your username or group has been added to the folder permissions

2. **Check if you're in the correct security group**
   - Access is often granted via security groups rather than to individual accounts
   - Contact IT to verify your account is in the appropriate security group

3. **Try accessing via a different path**
   - Sometimes accessing via UNC path (`\\server\share\folder`) works when mapped drives don't
   - Try both methods to see if one works

4. **Check for inherited permissions issues**
   - Sometimes permission issues occur when inheritance is broken
   - Contact IT support to investigate inheritance settings

### Can View Files But Cannot Edit

#### Symptoms
- Can open files but cannot save changes
- "Read-only" appears in the file properties or application title bar
- Receive "You don't have permission to save in this location" error

#### Solutions

1. **Check your permission level**
   - You likely have "Read" but not "Modify" or "Write" permissions
   - Request elevated permissions from the folder owner or IT support

2. **Check if the file is marked as read-only**
   - Right-click the file, select "Properties"
   - Uncheck the "Read-only" attribute if it's enabled
   - Note: This may not work if the read-only status is enforced by server permissions

3. **Save to a different location**
   - Save a copy to a location where you have write access
   - After editing, ask someone with permissions to replace the original file

4. **Check if the file is locked**
   - The file might be opened by another user with exclusive access
   - Wait until they close the file or contact them to coordinate access

### Cannot Delete Files

#### Symptoms
- "You need permission to perform this action" error when trying to delete
- Delete option is grayed out in context menu

#### Solutions

1. **Verify you have delete permissions**
   - Delete permissions are sometimes separate from modify permissions
   - Request specific delete permissions from the folder owner

2. **Check if the file is in use**
   - Files that are open cannot be deleted
   - Close all applications that might be using the file
   - Use Task Manager to check for background applications

3. **Check for special protection**
   - Some files are protected by system settings or policies
   - Contact IT if you need to delete a protected file

### Recently Lost Access

#### Symptoms
- You previously had access but suddenly cannot access files or folders
- Permissions changed without notification

#### Solutions

1. **Check for password expiration**
   - If your network password recently expired or changed, reconnect to the drive
   - Log out and log back in with your new credentials

2. **Verify security group membership**
   - Your account may have been removed from a security group
   - Contact IT to check if there have been recent group membership changes

3. **Check for reorganization**
   - During IT maintenance or reorganization, permissions sometimes change
   - Contact IT support to see if there have been recent structure changes

## How to Request Permission Changes

If you need access to a folder or additional permissions:

1. **Identify the resource owner**
   - Department drives usually have a designated owner
   - Project drives are typically managed by project managers
   - Company-wide resources are managed by IT

2. **Submit a formal request**
   - Email the resource owner with:
     - Specific location you need access to
     - Type of access needed (read, write, delete)
     - Business justification for access
     - How long you need access (temporary or permanent)

3. **Follow up**
   - If you don't receive a response within 48 hours, follow up with the resource owner
   - If the resource owner is unavailable, contact your manager or IT support

## Permission Inheritance Explained

Understanding how permissions work can help you troubleshoot issues:

- **Inheritance**: By default, files and subfolders inherit permissions from their parent folder
- **Explicit permissions**: Permissions specifically assigned to a file or folder
- **Inherited permissions**: Permissions that come from a parent folder
- **Deny permissions**: These override Allow permissions, even if Allow permissions are explicit

If you believe there's an inheritance issue causing your permission problem, contact IT support for assistance, as fixing inheritance issues typically requires administrative access.

## Getting Additional Help

If you've tried the solutions above and still have permission issues:

1. Gather specific details about the error message
2. Note the exact path of the resource you're trying to access
3. Document what actions you've already taken
4. Follow the guidelines on the [How to Report an Issue](/guide/report-issue) page to contact IT support