# Connection Errors

This guide addresses common network and connection errors that prevent access to shared drives.

## Common Connection Error Messages

- "Network path not found"
- "Network name is no longer available"
- "The network location cannot be reached"
- "Windows cannot access \\server\share"
- "There are currently no logon servers available"
- "The specified network name is no longer available"

## Troubleshooting Steps by Error Type

### Cannot Find Network Path

#### Symptoms
- "Network path not found" error
- Unable to see or connect to shared drives
- Red X appears on mapped network drives

#### Solutions

1. **Verify the server name and path**
   - Check for typos in the UNC path
   - Confirm the correct server name with IT if unsure

2. **Check network connectivity**
   - Verify you're connected to the company network
   - Try pinging the server: Open Command Prompt and type `ping servername`
   - If the ping fails, you have a network connectivity issue

3. **Verify VPN connection (for remote work)**
   - Ensure VPN is connected and functioning
   - Try disconnecting and reconnecting your VPN
   - Check VPN status in the system tray or connection settings

4. **Restart networking components**
   - Restart your computer
   - If that doesn't work, try resetting your network:
     - Windows: Run Command Prompt as administrator and type:
       ```
       ipconfig /release
       ipconfig /renew
       ipconfig /flushdns
       ```
     - Mac: Go to System Preferences > Network > Select your connection > Turn Off > Turn On

5. **Check for network adapter issues**
   - Update your network adapter drivers
   - Try disabling and re-enabling your network adapter

### Authentication Failures

#### Symptoms
- Repeatedly asked for credentials
- "Access denied" after entering credentials
- "The username or password is incorrect"

#### Solutions

1. **Verify your credentials**
   - Make sure you're using your current network password
   - Check if Caps Lock is turned on
   - Try using your full domain username (e.g., DOMAIN\username)

2. **Reset saved credentials**
   - Windows: 
     - Open Control Panel > Credential Manager
     - Find and remove saved credentials for the shared drive
     - Reconnect to the drive and enter credentials when prompted
   - Mac:
     - Open Keychain Access
     - Search for the server name
     - Delete the saved password
     - Reconnect and enter credentials when prompted

3. **Check account lock status**
   - Too many failed attempts may lock your account
   - Contact IT to check if your account is locked
   - Wait 15-30 minutes if account lockouts automatically reset

4. **Synchronize time settings**
   - Authentication can fail if your computer's clock is significantly different from the server's
   - Set your computer to automatically synchronize time

### Intermittent Connection Issues

#### Symptoms
- Works sometimes but not others
- Random disconnections
- Shared drives appear and disappear

#### Solutions

1. **Check for network instability**
   - Run a speed test to check your connection quality
   - Move closer to Wi-Fi router if using wireless
   - Switch to a wired connection if possible

2. **Check for resource conflicts**
   - Close bandwidth-heavy applications
   - Check for background downloads or updates
   - Limit the number of open network resources

3. **Increase timeout settings**
   - Windows:
     - Open Registry Editor (regedit)
     - Navigate to `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters`
     - Add or modify DWORD value `SessTimeout` to a higher value (e.g., 300 seconds)
     - Restart your computer
   - Note: Registry edits should be performed carefully; contact IT for assistance

4. **Update network drivers**
   - Download the latest network adapter drivers from your computer manufacturer's website
   - Install the updates and restart

### DNS Resolution Problems

#### Symptoms
- Can access by IP address but not by server name
- Long delays before connection errors
- "DNS name does not exist" errors

#### Solutions

1. **Flush DNS cache**
   - Windows: Open Command Prompt and run `ipconfig /flushdns`
   - Mac: Open Terminal and run `sudo killall -HUP mDNSResponder`

2. **Add server to hosts file**
   - With IT assistance, add the server and IP address to your hosts file
   - Windows: `C:\Windows\System32\drivers\etc\hosts`
   - Mac: `/etc/hosts`

3. **Try alternate DNS servers**
   - Change DNS settings to use company DNS servers
   - Contact IT for the correct DNS server addresses

4. **Check for DNS server issues**
   - The problem might be with the DNS servers themselves
   - Report the issue to IT if multiple users are affected

## VPN-Specific Connection Issues

### Symptoms
- Can access shared drives in the office but not remotely
- VPN connects but shared drives are inaccessible
- Very slow access to shared drives over VPN

### Solutions

1. **Verify split tunneling settings**
   - Make sure VPN is configured to route company network traffic
   - Contact IT to verify your VPN configuration

2. **Check VPN bandwidth limitations**
   - Some VPNs throttle bandwidth
   - Limit large file transfers during VPN sessions
   - Use remote desktop instead of direct file access for better performance

3. **Try reconnecting VPN**
   - Disconnect from VPN
   - Close the VPN client completely
   - Restart the VPN client and reconnect

4. **Update VPN client**
   - Download and install the latest version of your VPN client
   - Follow company instructions for VPN setup

## When to Contact IT Support

Contact IT support immediately if:

- Multiple users are experiencing the same connection issue
- You've tried all the suggested solutions and still can't connect
- Connection issues are recurring or persistent
- You're unable to access business-critical resources

Follow the guidelines on the [How to Report an Issue](/guide/report-issue) page to contact IT support with the appropriate information about your connection problem.