---
layout: home

hero:
  name: IT Knowledge Base
  text: Shared Drive Access Guide
  tagline: Quick solutions for common shared drive issues
  image:
    src: /network-drive-icon.png
    alt: Shared Drives
  actions:
    - theme: brand
      text: Get Started
      link: /guide/introduction
    - theme: alt
      text: Report an Issue
      link: /guide/report-issue

features:
  - icon: 🔍
    title: Troubleshooting
    details: Find solutions to common shared drive access problems, from permissions to connectivity issues.
    link: /troubleshooting/common-issues
  - icon: 📚
    title: User Guides
    details: Learn how to effectively use, navigate, and manage files on shared network drives.
    link: /user-guides/navigating-shared-drives
  - icon: 🛡️
    title: Permissions
    details: Understand how shared drive permissions work and how to request access changes.
    link: /user-guides/working-with-permissions
  - icon: 🔄
    title: Synchronization
    details: Solutions for syncing issues between local and network drives.
    link: /troubleshooting/syncing-issues
---

## Welcome to the Shared Drive Access Knowledge Base

This documentation site provides comprehensive guidance for working with shared network drives in our organization. Whether you're experiencing access issues, need to understand permissions, or want to learn best practices for file management, you'll find the resources you need here.

### Quick Access

- **[Introduction](/guide/introduction)**: Overview of this knowledge base
- **[Shared Drive Basics](/guide/shared-drive-basics)**: Fundamental concepts of shared drives
- **[Common Issues](/troubleshooting/common-issues)**: Solutions to frequently encountered problems
- **[How to Report an Issue](/guide/report-issue)**: Steps to follow when you need IT support

### Recently Updated

- **[Permission Problems](/troubleshooting/permission-problems)**: Updated troubleshooting guide for access denied errors
- **[Working with Permissions](/user-guides/working-with-permissions)**: New guide explaining permission levels
- **[Navigating Shared Drives](/user-guides/navigating-shared-drives)**: Enhanced with remote access instructions

### Popular Topics

- [Can't access shared drives from home?](/troubleshooting/connection-errors#vpn-specific-connection-issues)
- [Files won't sync between devices?](/troubleshooting/syncing-issues#files-wont-sync)
- [Need access to a new shared folder?](/user-guides/working-with-permissions#requesting-permission-changes)
- [Files showing as "read only"?](/troubleshooting/permission-problems#can-view-files-but-cannot-edit)