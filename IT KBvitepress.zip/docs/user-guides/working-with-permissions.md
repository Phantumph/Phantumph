# Working with Permissions

This guide explains how permissions work on shared drives and how to work effectively within the permission system.

## Understanding Permission Levels

Shared drive permissions control what actions users can perform on files and folders. The most common permission levels are:

### Basic Permission Levels

1. **Read** 
   - View files and folders
   - Open documents
   - Copy files to another location
   - Cannot make changes to files

2. **Write**
   - Create new files and folders
   - Edit existing documents
   - Cannot delete files created by others

3. **Modify**
   - Create new files and folders
   - Edit existing documents
   - Delete files and folders (including those created by others)

4. **Full Control**
   - All the above permissions
   - Change permissions for files and folders
   - Take ownership of files

### Special Permissions

Some specialized permissions may be set for specific purposes:

1. **List Folder Contents**
   - View folder names but not necessarily their contents
   
2. **Read & Execute**
   - Basic read permissions plus the ability to run executable files

3. **Traverse Folder/Execute File**
   - Access specific subfolders without having permissions to the parent folder

## How Permissions Are Applied

### Security Groups vs. Individual Accounts

1. **Security Groups**
   - Most permissions are assigned to security groups (e.g., "Marketing Team," "Project Managers")
   - Users inherit permissions from all groups they belong to
   - This approach makes permission management more efficient

2. **Individual Accounts**
   - Permissions can be assigned directly to individual user accounts
   - This is less common and generally avoided for maintenance reasons

### Permission Inheritance

1. **Default Inheritance**
   - By default, files and subfolders inherit permissions from their parent folder
   - Changes to parent folder permissions automatically apply to all contained items

2. **Breaking Inheritance**
   - Inheritance can be broken to set unique permissions on specific items
   - When inheritance is broken, the item gets a copy of the parent's permissions
   - Future changes to the parent no longer affect items with broken inheritance

### Permission Conflicts

1. **Explicit vs. Inherited Permissions**
   - Explicit permissions (directly applied) take precedence over inherited permissions

2. **Deny vs. Allow**
   - "Deny" permissions always override "Allow" permissions
   - If a user is denied access through any group membership, they cannot access the resource, even if other groups allow access

## Checking Your Permissions

### Windows

1. **View Permissions on a File or Folder**
   - Right-click the file or folder
   - Select "Properties"
   - Click the "Security" tab
   - Your permissions are listed under "Permissions for [Your Name]"

2. **Check Effective Permissions**
   - In the Security tab, click "Advanced"
   - Select the "Effective Access" tab
   - Enter your username
   - Click "View effective access"

### Mac

1. **View Basic Permissions**
   - Select the file or folder
   - Press Command+I to open the Info window
   - Look at the "Sharing & Permissions" section

2. **View Advanced Permissions**
   - Open Terminal
   - Use the command `ls -la [path]` to view detailed permissions

## Working Within Your Permission Limits

### When You Have Read-Only Access

1. **Save a Local Copy**
   - If you need to edit a read-only file, save a copy to a location where you have write access
   - Make your changes to the copy
   - Ask the file owner to update the original if needed

2. **Request Temporary Access**
   - If you need to make changes directly to the original file, request temporary elevated permissions
   - See the "Requesting Permission Changes" section below

### When You Have Write But Not Delete Access

1. **Updating Content**
   - You can edit files but not remove them
   - Update content within existing files rather than deleting and recreating them

2. **Managing Your Own Files**
   - Keep track of files you create in shared locations
   - If you need to delete files that you can't remove, contact the folder owner

### When You Have Full Access

1. **Exercise caution**
   - Having high-level permissions comes with responsibility
   - Be careful not to delete or modify important files
   - Consider creating backups before major changes

2. **Maintain permission structure**
   - Don't modify permissions unless you're authorized to do so
   - Follow company guidelines for permission assignments

## Requesting Permission Changes

### When to Request Permission Changes

1. **New Project Access**
   - When you join a new project or team
   - When a project enters a new phase requiring different resources

2. **Temporary Needs**
   - Short-term collaborations
   - Covering for a colleague during absence

3. **Role Changes**
   - When your job responsibilities change
   - After promotions or department transfers

### How to Request Permission Changes

1. **Standard Process**
   - Identify the resource owner (typically listed in the folder documentation or available from your manager)
   - Email your request with:
     - Specific resource location (full path)
     - Type of access needed (read, write, etc.)
     - Business justification
     - Duration (permanent or temporary with end date)
   - Include your manager in the request

2. **Urgent Access**
   - For time-sensitive needs, follow the standard process but mark as "Urgent"
   - Call the IT helpdesk after submitting the request
   - Be prepared to provide manager approval

3. **Temporary Delegation**
   - If you need to delegate your access to someone else temporarily
   - Both you and your manager must approve the delegation request
   - Include specific start and end dates

### After Submitting a Request

1. **Response Times**
   - Standard requests: 1-2 business days
   - Urgent requests: Same business day if submitted before 3 PM
   - Complex requests may take longer

2. **Verifying New Permissions**
   - After being notified of granted permissions
   - Test access as soon as possible
   - Report any issues immediately

## Common Permission Scenarios

### Project Handover

When transferring project ownership:

1. **Inventory relevant files**
   - Create a list of all files and folders requiring permission changes
   
2. **Document current permissions**
   - Note who currently has access and at what levels
   
3. **Submit comprehensive request**
   - Request all changes at once rather than piecemeal
   - Include both people gaining and losing access

### Departmental Reorganization

When department structures change:

1. **Work with IT proactively**
   - Provide advance notice of reorganization
   - Supply new organizational charts
   
2. **Plan transition period**
   - Consider temporary dual access during transition
   - Set clear cutover dates

### Contractor/Temporary Access

When external parties need access:

1. **Limit scope carefully**
   - Grant access only to specific necessary folders
   - Avoid broad department or project-level access
   
2. **Set expiration dates**
   - All temporary access should have a defined end date
   - Calendar reminders for access review
   
3. **Use dedicated folders when possible**
   - Create specific folders for external sharing
   - Avoid granting access to internal working folders

## Best Practices

1. **Only request access you need**
   - Don't ask for higher permissions "just in case"
   - Request the minimum necessary for your work

2. **Respect confidentiality**
   - Just because you can access information doesn't mean you should
   - Follow company data confidentiality policies

3. **Report permission issues**
   - If you discover incorrect permissions (too high or too low)
   - Report to IT or the resource owner

4. **Periodic access reviews**
   - Regularly review your access to ensure it's still appropriate
   - Volunteer to relinquish access you no longer need

5. **Document your permissions**
   - Keep track of special access you've been granted
   - Makes transitions easier when changing roles

## Getting Help

If you encounter difficulties with permissions on shared drives:

- Refer to the [Permission Problems](/troubleshooting/permission-problems) page for troubleshooting help
- Contact IT Support following the guidelines on the [How to Report an Issue](/guide/report-issue) page