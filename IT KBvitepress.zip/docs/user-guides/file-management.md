# File Management on Shared Drives

This guide provides best practices and instructions for effectively managing files on shared drives in our organization.

## File Organization Principles

### Naming Conventions

Good file naming is essential when multiple people access shared files:

1. **Be descriptive but concise**
   - Use names that clearly indicate the file's content
   - Example: `Q1_2023_Marketing_Budget.xlsx` instead of `Budget.xlsx`

2. **Use consistent formatting**
   - Date format: YYYY-MM-DD (e.g., `2023-03-15_Meeting_Minutes.docx`)
   - Version numbering: v1.0, v1.1, v2.0 (e.g., `Project_Plan_v2.0.docx`)

3. **Avoid special characters**
   - Don't use: `/ \ : * ? " < > | # % & { } $ ! ' @ + = `
   - These can cause issues with certain systems or applications

4. **Use underscores or hyphens instead of spaces**
   - Example: `Annual_Report_2023.pdf` or `Annual-Report-2023.pdf`
   - This prevents issues with some web systems and command-line tools

### Folder Structure

1. **Create logical hierarchies**
   - Group related files together
   - Limit folder nesting to 3-4 levels deep

2. **Use descriptive folder names**
   - Names should clearly indicate the contents
   - Consider including department or project names for context

3. **Organize by function or project**
   - Group files by their purpose or the project they belong to
   - Avoid organizing solely by file type

4. **Include README files**
   - Place a README.txt in complex folders to explain the organization system
   - Update README files when the folder structure changes

## Working with Files

### Opening Files

1. **Check if files are already in use**
   - Look for lock icons or "Read-Only" indicators
   - Some applications will notify you if someone else has the file open

2. **Open files directly from the shared drive**
   - Double-click to open with the default application
   - Right-click and select "Open with" to choose a specific application

3. **Handle read-only notifications**
   - If you get a "Read-Only" notification, someone else may be editing the file
   - You can still view the file, but save a local copy if you need to make changes

### Saving Files

1. **Save directly to the shared drive**
   - Save files directly to their intended location
   - Avoid saving to your desktop or documents folder and copying later

2. **Use "Save As" for new versions**
   - Create new versions of important documents rather than overwriting
   - Follow version numbering conventions

3. **Close files when done**
   - Close files when you're not actively working on them
   - This releases locks and allows others to edit

4. **Check successful saves**
   - Verify the file appears in the folder after saving
   - Check the timestamp to ensure it updated correctly

### Copying and Moving Files

1. **Maintain folder structures**
   - When moving multiple files, maintain the original folder structure if appropriate

2. **Use cut/paste for moving**
   - Cut (Ctrl+X) and Paste (Ctrl+V) for moving files within the same shared drive
   - Copy and paste, then delete the original when moving between different drives

3. **Verify successful operations**
   - Check that files appear in the destination and are removed from the source (if moved)
   - Verify file sizes match the originals

4. **Be cautious with drag-and-drop**
   - In Windows, dragging between drives copies by default
   - Hold Shift while dragging to move instead of copy

### Deleting Files

1. **Check permissions before deleting**
   - Ensure you have the right to delete files
   - When in doubt, consult with the file owner or your manager

2. **Consider using an archive folder**
   - Instead of deleting, move outdated files to an "Archive" folder
   - This preserves history while keeping active folders clean

3. **Communicate before mass deletions**
   - Inform team members before deleting shared files
   - Consider creating a "To Be Deleted" folder with a deletion date

4. **Empty Recycle Bin/Trash**
   - Files deleted from shared drives may go to your Recycle Bin/Trash
   - Remember to empty it periodically if space is a concern

## Version Control

### Manual Version Control

1. **Include version numbers in filenames**
   - Example: `Project_Proposal_v1.0.docx`, `Project_Proposal_v1.1.docx`
   - Increment the number for each significant change

2. **Use a version log**
   - Create a simple text file listing versions and changes
   - Include date, version number, who made changes, and what changed

3. **Keep versions organized**
   - Store old versions in a "Previous Versions" or "Archive" subfolder
   - Keep only the current version in the main working folder

### Using Built-in Version Features

1. **Microsoft Office Version History**
   - Many Microsoft Office applications track version history automatically when saving to shared drives
   - Access by clicking File > Info > Version History

2. **PDF version comparison**
   - Adobe Acrobat and some other PDF tools can compare document versions
   - Use View > Compare Documents in Adobe Acrobat

## Collaborative Editing

### Simultaneous Editing

1. **Use applications that support co-authoring**
   - Microsoft Office 365 applications support simultaneous editing
   - Google Workspace (formerly G Suite) also supports real-time collaboration

2. **Be aware of editing indicators**
   - Look for user icons or highlights showing where others are working
   - Pay attention to notifications about other editors

3. **Communicate while collaborating**
   - Use comments or chat features in the application
   - Consider having a separate chat or call open during intensive collaboration

### Managing Edit Conflicts

1. **Understanding conflict resolution**
   - When multiple people edit a file, conflicts may occur
   - Most collaboration tools have built-in conflict resolution features

2. **Handling "File in Use" messages**
   - If you get a "File in Use" message, you can:
     - Open a read-only copy
     - Receive notification when the file becomes available
     - Open the file and work on different sections (if the application supports it)

3. **Merging changes**
   - If you need to merge changes from different versions:
     - Use the Compare and Merge features in applications that support them
     - Manually integrate changes if necessary
     - Consider using proper version control systems for complex documents

## Security Best Practices

1. **Respect confidentiality**
   - Don't place sensitive files in broadly accessible locations
   - Use appropriate restricted folders for confidential information

2. **Don't change permissions yourself**
   - Contact IT or the folder owner if permissions need to be changed
   - Don't share access by copying files to less secure locations

3. **Report suspicious files**
   - If you notice unusual files or potential security issues
   - Contact IT security immediately

4. **Lock your computer when away**
   - Always lock your computer (Win+L or ⌘+Control+Q) when stepping away
   - This prevents unauthorized access to shared drives through your account

## Tips for Specific File Types

### Microsoft Office Files

1. **Use templates**
   - Use company-approved templates for consistent formatting
   - Templates are usually stored in a dedicated "Templates" folder

2. **Enable AutoSave for Office 365**
   - AutoSave helps prevent data loss during collaborative editing
   - Only works when saving to supported cloud locations

3. **Check for compatibility mode**
   - Files in compatibility mode have limited features
   - Consider upgrading older file formats if everyone has newer software

### Large Files

1. **Compress before sharing**
   - Zip large files or folders before placing on shared drives
   - This saves space and improves transfer times

2. **Consider alternatives for very large files**
   - Use file sharing services for extremely large files
   - Consult IT for guidance on files over 500MB

3. **Be mindful of storage limits**
   - Shared drives often have quotas
   - Delete unnecessary files or move them to appropriate archive storage

## Getting Help

If you encounter difficulties with file management on shared drives:

- Refer to the [Common Issues](/troubleshooting/common-issues) page for troubleshooting help
- Contact IT Support following the guidelines on the [How to Report an Issue](/guide/report-issue) page