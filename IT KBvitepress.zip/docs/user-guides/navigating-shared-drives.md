# Navigating Shared Drives

This guide provides instructions for effectively navigating and using shared drives in our organization.

## Accessing Shared Drives

### On Windows

1. **Using File Explorer**:
   - Open File Explorer from the taskbar or Start menu
   - In the navigation pane, look for "Network" or "This PC"
   - Mapped drives will appear under "This PC" with assigned drive letters (e.g., Z: Department Files)
   - Network shares will appear under "Network" grouped by server name

2. **Mapping a Network Drive**:
   - Open File Explorer
   - Click on "This PC" in the left pane
   - Click on "Map network drive" in the Computer tab
   - Select an available drive letter
   - Enter the path to the shared folder (e.g., `\\server\department`)
   - Check "Reconnect at sign-in" if you want this drive available each time you log in
   - Click "Finish"

3. **Using Run Dialog**:
   - Press Win+R to open the Run dialog
   - Type the UNC path (e.g., `\\server\department`)
   - Press Enter

### On Mac

1. **Using Finder**:
   - Click on Finder in the Dock
   - Select "Go" from the menu bar, then "Connect to Server"
   - Enter the server address (e.g., `smb://server/department`)
   - Click "Connect"
   - Enter your network credentials when prompted
   - Select the shared folders you want to mount

2. **Using Recent Connections**:
   - Click on Finder in the Dock
   - Select "Go" from the menu bar, then "Connect to Server"
   - Click the clock icon to see recent connections
   - Select the server from the dropdown list

3. **Adding to Favorites**:
   - Once connected to a server, drag the shared folder to the Favorites section of the Finder sidebar
   - The share will now be easily accessible for future sessions

## Understanding Folder Structure

Our organization uses a standardized folder structure across shared drives:

### Department Drives

```
Department/
├── Admin/                # Administrative documents
├── Projects/             # Project-specific folders
│   ├── Project1/
│   ├── Project2/
│   └── ...
├── Resources/            # Department resources and references
├── Templates/            # Standard templates for department use
└── Archive/              # Completed or inactive materials
```

### Project Drives

```
ProjectName/
├── 01_Planning/          # Project planning documents
├── 02_Execution/         # Working documents and deliverables
├── 03_Communications/    # Meeting notes and communications
├── 04_Resources/         # Reference materials and resources
└── 05_Archive/           # Outdated or superseded materials
```

### Company-Wide Drive

```
Company/
├── Announcements/        # Company-wide announcements
├── HR/                   # HR policies and forms
├── IT/                   # IT documentation and guides
├── Marketing/            # Marketing materials and brand assets
└── Policies/             # Company policies and procedures
```

## Navigation Best Practices

1. **Use the search function**
   - When looking for specific files, use the search box in File Explorer or Finder
   - Search within specific folders to narrow results
   - Use file type filters (e.g., `*.docx` or `*.pdf`) to find specific file types

2. **Create shortcuts**
   - Create shortcuts to frequently accessed folders on your desktop
   - Add important locations to your Quick Access/Favorites bar

3. **Use breadcrumbs**
   - The path shown at the top of File Explorer or Finder (breadcrumb trail) helps you understand where you are
   - Click on any part of the path to navigate to that level

4. **Use views effectively**
   - Switch between list, details, tiles, and icon views depending on your needs
   - Sort by name, date, type, or size as needed
   - Group files by properties for easier navigation of large folders

5. **Preview files without opening**
   - Windows: Select a file and press Alt+P to open the preview pane
   - Mac: Select a file and press Space for Quick Look

## Working with Network Paths

### Understanding UNC Paths

Universal Naming Convention (UNC) paths are formatted as:
```
\\server\share\folder\subfolder\file.docx
```

Where:
- `server` is the name of the file server
- `share` is the name of the shared resource
- Remaining elements are folder names and file names

### Using UNC Paths Effectively

1. **Direct access**:
   - UNC paths work in the address bar of File Explorer
   - They work in the Run dialog (Win+R)
   - They work in most "Open File" and "Save As" dialogs

2. **Creating shortcuts with UNC paths**:
   - Right-click on the desktop or in a folder
   - Select New > Shortcut
   - Enter the UNC path
   - Give the shortcut a recognizable name

3. **Sharing locations with colleagues**:
   - Copy the UNC path by clicking in the address bar and pressing Ctrl+C
   - Share the exact location with colleagues via email or chat

## Offline Access

For times when you need to work without network connectivity:

1. **Windows Offline Files**:
   - Right-click on a network folder
   - Select "Always available offline"
   - Files will synchronize when you're connected and be available when disconnected

2. **Manual copying**:
   - Copy important files to your local drive before disconnecting
   - Remember to copy them back to the shared drive when done

3. **Using sync tools**:
   - If your organization uses OneDrive, Google Drive, or similar tools
   - Configure syncing for important shared folders
   - Refer to [Syncing Issues](/troubleshooting/syncing-issues) for help with sync problems

## Getting Help

If you encounter difficulties navigating shared drives:

- Refer to the [Common Issues](/troubleshooting/common-issues) page for troubleshooting help
- Contact IT Support following the guidelines on the [How to Report an Issue](/guide/report-issue) page