# How to Report an Issue

If you're experiencing problems with shared drives that aren't resolved using the troubleshooting guides in this knowledge base, you'll need to report the issue to the IT support team. This guide explains how to submit an effective support request.

## Before Reporting an Issue

Before contacting IT support, try these steps:

1. **Check this knowledge base** for solutions to common problems
2. **Restart your computer** to see if the issue resolves
3. **Verify your network connection** is stable
4. **Ask colleagues** if they're experiencing the same issue (to determine if it's a widespread problem)

## What Information to Include

When reporting a shared drive issue, include the following details to help IT resolve your problem faster:

1. **Your name and department**
2. **Your computer details** (operating system, version)
3. **The specific shared drive or folder** you're having trouble with (exact path if possible)
4. **Complete error messages** (copy and paste the exact text)
5. **When the problem started** (date and time)
6. **What you were doing** when the error occurred
7. **Who else is affected** (if known)
8. **Screenshots** of any error messages or problematic behavior
9. **Steps you've already taken** to try to resolve the issue

## How to Submit a Support Request

### Option 1: IT Support Portal

1. Visit the [IT Support Portal](http://support.example.com)
2. Log in with your company credentials
3. Click "New Ticket"
4. Select "Shared Drive/Network Storage" from the issue category dropdown
5. Fill in the required information
6. Attach any relevant screenshots
7. Submit the ticket

### Option 2: Email Support

Send an email to [itsupport@example.com](mailto:itsupport@example.com) with:

- Subject line: "Shared Drive Issue - [Brief Description]"
- All the information listed in the "What Information to Include" section above

### Option 3: IT Support Hotline

For urgent issues affecting multiple users or preventing critical work:

Call the IT support desk at ext. 1234 (or +1-555-123-4567)

## Support Hours and Response Times

- **Regular Support Hours**: Monday-Friday, 8:00 AM - 6:00 PM
- **After-Hours Support**: Available for critical issues only
- **Expected Response Times**:
  - Critical issues: 1-2 hours
  - High priority: 4 hours
  - Medium priority: 1 business day
  - Low priority: 2-3 business days

## Tracking Your Support Request

After submitting a request:

1. You'll receive a confirmation email with a ticket number
2. Use this number for all follow-up communications
3. You can check the status of your request in the IT Support Portal

## Escalation Process

If your issue is not being resolved in a timely manner:

1. Reply to your ticket requesting an update
2. If no response within 24 hours, contact your department's IT liaison
3. For business-critical issues, ask your manager to contact the IT Manager