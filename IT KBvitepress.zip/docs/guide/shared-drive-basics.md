# Shared Drive Basics

This guide covers the fundamental concepts and operations related to shared drives in our organization.

## What are Shared Drives?

Shared drives (sometimes called network drives, shared folders, or network shares) are storage locations on the network that multiple users can access. They facilitate collaboration by allowing teams to work on the same set of files without having to email documents back and forth.

## Types of Shared Drives in Our Organization

Our organization uses several types of shared drives:

1. **Department Drives**: Accessible to members of specific departments
2. **Project Drives**: Created for specific projects and accessible to project team members
3. **Company-Wide Drives**: Accessible to all employees for shared resources
4. **Personal Drives**: Private storage spaces allocated to individual employees

## Access Control Basics

Access to shared drives is controlled through:

- **Authentication**: Verifying your identity through your network credentials
- **Authorization**: Determining what you can do with files based on permissions
- **Permissions**: Specific rights granted to users or groups (read, write, modify, etc.)

## Common Terminology

- **Mapping a Drive**: Creating a shortcut to a network location that appears as a local drive on your computer
- **UNC Path**: Universal Naming Convention path (e.g., `\\server\share\folder`) used to access shared resources
- **Access Control List (ACL)**: A list that defines which users or groups are granted or denied access
- **Read Permission**: Allows viewing files but not changing them
- **Write Permission**: Allows creating and modifying files
- **Full Control**: Complete access to read, write, modify, and change permissions

## Basic Operations

### Connecting to a Shared Drive

#### Windows:
1. Open File Explorer
2. Click on "This PC" in the left panel
3. Click on "Map network drive" in the Computer tab
4. Select a drive letter and enter the path to the shared folder
5. Check "Reconnect at sign-in" if you want the drive to be available each time you log in
6. Click "Finish"

#### Mac:
1. Click on the Finder icon in the Dock
2. Click "Go" in the menu bar and select "Connect to Server"
3. Enter the server address (e.g., `smb://server/share`)
4. Click "Connect" and enter your credentials when prompted

### Disconnecting from a Shared Drive

#### Windows:
1. Open File Explorer
2. Right-click on the mapped drive
3. Select "Disconnect"

#### Mac:
1. In Finder, click the eject icon next to the shared drive in the sidebar
2. Alternatively, drag the drive icon to the Trash

## Best Practices

1. **Always save important files to shared drives** rather than your local computer to ensure they're backed up
2. **Don't disconnect shared drives** while files are being transferred or when documents are open
3. **Close files when not in use** to prevent locking issues for other users
4. **Be mindful of storage limits** on shared drives
5. **Follow the established folder structure** to keep files organized