import { defineConfig } from "vitepress";

export default defineConfig({
  lang: "en-US",
  title: "IT Knowledge Base",
  description: "Documentation for Shared Drive Access Issues",
  outDir: "../dist",

  themeConfig: {
    nav: [
      { text: "Guide", link: "/guide/introduction" },
      { text: "Troubleshooting", link: "/troubleshooting/common-issues" },
      { text: "User Guides", link: "/user-guides/navigating-shared-drives" },
      {
        text: "Support",
        link: "/guide/report-issue"
      },
    ],

    sidebar: [
      {
        text: "Getting Started",
        items: [
          { text: "Introduction", link: "/guide/introduction" },
          { text: "Shared Drive Basics", link: "/guide/shared-drive-basics" },
          { text: "How to Report an Issue", link: "/guide/report-issue" },
        ],
      },
      {
        text: "Troubleshooting",
        items: [
          { text: "Common Issues", link: "/troubleshooting/common-issues" },
          { text: "Permission Problems", link: "/troubleshooting/permission-problems" },
          { text: "Connection Errors", link: "/troubleshooting/connection-errors" },
          { text: "Syncing Issues", link: "/troubleshooting/syncing-issues" },
        ],
      },
      {
        text: "User Guides",
        items: [
          { text: "Navigating Shared Drives", link: "/user-guides/navigating-shared-drives" },
          { text: "File Management", link: "/user-guides/file-management" },
          { text: "Working with Permissions", link: "/user-guides/working-with-permissions" },
        ],
      },
    ],

    socialLinks: [
      { icon: "github", link: "https://github.com/example/it-knowledge-base" },
    ],

    footer: {
      message: "IT Knowledge Base for Shared Drive Access",
      copyright: "© 2023 Company Name. All rights reserved."
    },

    search: {
      provider: "local"
    }
  },

  vite: {
    server: {
      strictPort: false,
    },
  },
});